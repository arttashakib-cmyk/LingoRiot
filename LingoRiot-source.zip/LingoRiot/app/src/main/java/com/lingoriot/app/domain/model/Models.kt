package com.lingoriot.app.domain.model

import java.time.Instant

/**
 * Core domain models for LingoRiot learning engine.
 */

enum class Pathway {
    RAP, ROCK, POP, STREET, EVERYDAY
}

enum class Difficulty {
    BEGINNER, ELEMENTARY, INTERMEDIATE, UPPER_INTERMEDIATE, ADVANCED
}

enum class Register {
    FORMAL, NEUTRAL, INFORMAL, SLANG, SARCASTIC, HUMOROUS
}

enum class ExerciseType {
    LISTENING_COMPREHENSION,
    MEANING_RECOGNITION,
    MISSING_PHRASE,
    WORD_ORDER,
    SLANG_DECODER,
    NATURAL_OR_UNNATURAL,
    CONTEXT_MATCH,
    CONVERSATION_COMEBACK,
    AUDIO_MEMORY,
    DELAYED_RECALL,
    TYPED_PRODUCTION,
    SENTENCE_RECONSTRUCTION,
    ACTIVE_RECALL,
    PRONUNCIATION_PRACTICE
}

enum class ReviewRating {
    AGAIN, HARD, GOOD, EASY
}

enum class LearningState {
    NEW, LEARNING, REVIEW, RELEARNING, MASTERED
}

data class Expression(
    val id: String,
    val englishText: String,
    val persianMeaning: String,
    val contextualExplanation: String,
    val register: Register,
    val topic: String,
    val difficulty: Difficulty,
    val exampleSentences: List<String>,
    val alternatives: List<String>,
    val usageWarnings: String?,
    val pronunciationGuide: String?,
    val audioAssetId: String?,
    val sourceAttribution: String?,
    val tags: List<String>,
    val pathway: Pathway
)

data class Lesson(
    val id: String,
    val titleFa: String,
    val titleEn: String,
    val pathway: Pathway,
    val difficulty: Difficulty,
    val descriptionFa: String,
    val expressionIds: List<String>,
    val orderIndex: Int,
    val estimatedMinutes: Int
)

data class AudioAsset(
    val id: String,
    val resourceName: String,
    val durationMs: Long,
    val attribution: String?
)

data class Exercise(
    val id: String,
    val type: ExerciseType,
    val expressionId: String?,
    val lessonId: String?,
    val promptFa: String,
    val promptEn: String?,
    val options: List<String>?,
    val correctAnswer: String,
    val explanationFa: String,
    val audioAssetId: String?,
    val timeLimitSeconds: Int?
)

data class ExpressionReviewState(
    val expressionId: String,
    val successfulRecalls: Int = 0,
    val failedRecalls: Int = 0,
    val lastReviewedAt: Instant? = null,
    val nextReviewAt: Instant? = null,
    val easeFactor: Double = 2.5,
    val intervalDays: Double = 0.0,
    val repetitions: Int = 0,
    val learningState: LearningState = LearningState.NEW,
    val recentQuality: Int = 0, // 0-5 SM-2 style
    val contextTags: List<String> = emptyList()
)

data class LearningSession(
    val id: String,
    val startedAt: Instant,
    val endedAt: Instant?,
    val pathway: Pathway?,
    val exercisesCompleted: Int,
    val correctCount: Int,
    val xpEarned: Int,
    val durationSeconds: Long
)

data class ExerciseAttempt(
    val id: String,
    val exerciseId: String,
    val expressionId: String?,
    val sessionId: String,
    val isCorrect: Boolean,
    val userAnswer: String,
    val responseTimeMs: Long,
    val rating: ReviewRating?,
    val timestamp: Instant,
    val xpAwarded: Int
)

data class UserProgress(
    val totalExpressionsEncountered: Int = 0,
    val totalSuccessfulRecalls: Int = 0,
    val totalXp: Int = 0,
    val currentLevel: Int = 1,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val lastActiveDate: String? = null, // yyyy-MM-dd
    val listeningAccuracy: Float = 0f,
    val recallAccuracy: Float = 0f,
    val productionAccuracy: Float = 0f,
    val totalSessionSeconds: Long = 0
)

data class Achievement(
    val id: String,
    val titleFa: String,
    val descriptionFa: String,
    val unlockedAt: Instant?,
    val isUnlocked: Boolean
)

data class UserPreferences(
    val theme: String = "dark",
    val playbackSpeed: Float = 1.0f,
    val dailyTargetMinutes: Int = 15,
    val remindersEnabled: Boolean = false,
    val soundEffectsEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val onlineFeaturesEnabled: Boolean = false,
    val preferredPathways: List<Pathway> = listOf(Pathway.EVERYDAY),
    val estimatedLevel: Difficulty = Difficulty.BEGINNER,
    val mainGoal: String = "conversation",
    val onboardingCompleted: Boolean = false
)

data class ScenarioStep(
    val id: String,
    val promptFa: String,
    val promptEn: String?,
    val expectedResponses: List<String>,
    val feedbackCorrectFa: String,
    val feedbackIncorrectFa: String,
    val formalityNote: String?,
    val alternatives: List<String>,
    val nextStepId: String?
)

data class ConversationScenario(
    val id: String,
    val titleFa: String,
    val titleEn: String,
    val descriptionFa: String,
    val difficulty: Difficulty,
    val steps: List<ScenarioStep>
)
