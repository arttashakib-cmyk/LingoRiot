package com.lingoriot.app

import android.app.Application
import com.lingoriot.app.data.local.LingoRiotDatabase

class LingoRiotApp : Application() {
    lateinit var database: LingoRiotDatabase
        private set

    override fun onCreate() {
        super.onCreate()
        database = LingoRiotDatabase.getInstance(this)
        LingoRiotDatabase.seedIfNeeded(database)
    }
}
