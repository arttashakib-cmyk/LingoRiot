package com.lingoriot.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Dark-first music-inspired palette
val Charcoal = Color(0xFF121212)
val DeepSurface = Color(0xFF1E1E1E)
val ElevatedSurface = Color(0xFF2A2A2A)
val ElectricViolet = Color(0xFFBB86FC)
val WarmOrange = Color(0xFFFF8A65)
val AccentCyan = Color(0xFF03DAC6)
val OnDark = Color(0xFFE0E0E0)
val OnDarkMuted = Color(0xFFB0B0B0)

private val DarkColorScheme = darkColorScheme(
    primary = ElectricViolet,
    onPrimary = Color.Black,
    secondary = WarmOrange,
    onSecondary = Color.Black,
    tertiary = AccentCyan,
    background = Charcoal,
    onBackground = OnDark,
    surface = DeepSurface,
    onSurface = OnDark,
    surfaceVariant = ElevatedSurface,
    onSurfaceVariant = OnDarkMuted,
    error = Color(0xFFCF6679),
    onError = Color.Black
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF7C4DFF),
    secondary = Color(0xFFFF7043),
    background = Color(0xFFFAFAFA),
    surface = Color.White
)

@Composable
fun LingoRiotTheme(
    darkTheme: Boolean = true, // dark-first
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
