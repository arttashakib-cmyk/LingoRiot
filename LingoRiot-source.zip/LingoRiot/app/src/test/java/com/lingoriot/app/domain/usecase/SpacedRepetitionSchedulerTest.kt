package com.lingoriot.app.domain.usecase

import com.lingoriot.app.domain.model.ExpressionReviewState
import com.lingoriot.app.domain.model.LearningState
import com.lingoriot.app.domain.model.ReviewRating
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant

class SpacedRepetitionSchedulerTest {

    private val now = Instant.parse("2026-10-14T10:00:00Z")

    @Test
    fun `new item with Good becomes Learning with 1 day interval`() {
        val state = ExpressionReviewState(expressionId = "expr1")
        val result = SpacedRepetitionScheduler.schedule(state, ReviewRating.GOOD, now)

        assertEquals(1, result.successfulRecalls)
        assertEquals(0, result.failedRecalls)
        assertEquals(1, result.repetitions)
        assertEquals(1.0, result.intervalDays, 0.01)
        assertEquals(LearningState.LEARNING, result.learningState)
        assertTrue(result.nextReviewAt!!.isAfter(now))
    }

    @Test
    fun `Again resets to Relearning with short interval`() {
        val state = ExpressionReviewState(
            expressionId = "expr1",
            successfulRecalls = 3,
            repetitions = 3,
            intervalDays = 7.0,
            easeFactor = 2.5,
            learningState = LearningState.REVIEW
        )
        val result = SpacedRepetitionScheduler.schedule(state, ReviewRating.AGAIN, now)

        assertEquals(1, result.failedRecalls)
        assertEquals(0, result.repetitions)
        assertEquals(LearningState.RELEARNING, result.learningState)
        assertTrue(result.intervalDays < 1.0)
        assertTrue(result.easeFactor < 2.5)
    }

    @Test
    fun `Easy increases interval more than Good`() {
        val state = ExpressionReviewState(
            expressionId = "expr1",
            repetitions = 2,
            intervalDays = 3.0,
            easeFactor = 2.5,
            learningState = LearningState.LEARNING
        )
        val good = SpacedRepetitionScheduler.schedule(state, ReviewRating.GOOD, now)
        val easy = SpacedRepetitionScheduler.schedule(state, ReviewRating.EASY, now)

        assertTrue(easy.intervalDays > good.intervalDays)
    }

    @Test
    fun `isDue returns true for null nextReview and NEW state`() {
        val state = ExpressionReviewState(expressionId = "expr1")
        assertTrue(SpacedRepetitionScheduler.isDue(state, now))
    }

    @Test
    fun `isDue returns false for future nextReview`() {
        val state = ExpressionReviewState(
            expressionId = "expr1",
            nextReviewAt = now.plusSeconds(3600),
            learningState = LearningState.REVIEW
        )
        assertFalse(SpacedRepetitionScheduler.isDue(state, now))
    }

    @Test
    fun `calculateLevel is deterministic`() {
        assertEquals(1, SpacedRepetitionScheduler.calculateLevel(0))
        assertEquals(1, SpacedRepetitionScheduler.calculateLevel(49))
        assertEquals(2, SpacedRepetitionScheduler.calculateLevel(50))
        assertEquals(3, SpacedRepetitionScheduler.calculateLevel(200))
    }

    @Test
    fun `XP for review is positive for successful ratings`() {
        val state = ExpressionReviewState(expressionId = "e1", learningState = LearningState.LEARNING)
        assertTrue(SpacedRepetitionScheduler.calculateReviewXp(ReviewRating.GOOD, state) > 0)
        assertEquals(0, SpacedRepetitionScheduler.calculateReviewXp(ReviewRating.AGAIN, state))
    }
}
