package com.lingoriot.app.domain.usecase

import com.lingoriot.app.domain.model.ExpressionReviewState
import com.lingoriot.app.domain.model.LearningState
import com.lingoriot.app.domain.model.ReviewRating
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * SM-2 inspired spaced repetition scheduler adapted for conversational expressions.
 *
 * Deterministic, tested policy:
 * - Quality mapping: Again=0, Hard=2, Good=3, Easy=5 (SM-2 scale 0-5)
 * - Ease factor starts at 2.5, minimum 1.3
 * - Interval progression follows SM-2 with small adaptations for language items
 * - Failed recalls (Again) reset to relearning with short interval
 * - Easy responses get a small bonus multiplier
 *
 * This is explicit and reproducible for unit testing.
 */
object SpacedRepetitionScheduler {

    private const val MIN_EASE = 1.3
    private const val DEFAULT_EASE = 2.5

    fun schedule(
        current: ExpressionReviewState,
        rating: ReviewRating,
        now: Instant = Instant.now()
    ): ExpressionReviewState {
        val quality = when (rating) {
            ReviewRating.AGAIN -> 0
            ReviewRating.HARD -> 2
            ReviewRating.GOOD -> 3
            ReviewRating.EASY -> 5
        }

        return when {
            quality < 3 -> handleFailure(current, quality, now)
            else -> handleSuccess(current, quality, rating, now)
        }
    }

    private fun handleFailure(
        current: ExpressionReviewState,
        quality: Int,
        now: Instant
    ): ExpressionReviewState {
        val newEase = max(MIN_EASE, current.easeFactor - 0.2)
        val nextIntervalHours = when {
            current.failedRecalls >= 2 -> 0.25 // 15 min for repeated failure
            else -> 0.5 // 30 min
        }
        val nextReview = now.plus((nextIntervalHours * 60).toLong(), ChronoUnit.MINUTES)

        return current.copy(
            failedRecalls = current.failedRecalls + 1,
            lastReviewedAt = now,
            nextReviewAt = nextReview,
            easeFactor = newEase,
            intervalDays = nextIntervalHours / 24.0,
            repetitions = 0,
            learningState = LearningState.RELEARNING,
            recentQuality = quality
        )
    }

    private fun handleSuccess(
        current: ExpressionReviewState,
        quality: Int,
        rating: ReviewRating,
        now: Instant
    ): ExpressionReviewState {
        val newRepetitions = current.repetitions + 1
        val newEase = max(
            MIN_EASE,
            current.easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02))
        )

        val newIntervalDays = when {
            newRepetitions == 1 -> 1.0
            newRepetitions == 2 -> 3.0
            else -> {
                val base = current.intervalDays * newEase
                when (rating) {
                    ReviewRating.EASY -> base * 1.3
                    ReviewRating.HARD -> base * 0.85
                    else -> base
                }
            }
        }.coerceAtLeast(0.5)

        val nextReview = now.plus((newIntervalDays * 24 * 60).toLong(), ChronoUnit.MINUTES)

        val newState = when {
            newRepetitions >= 5 && newIntervalDays >= 21 -> LearningState.MASTERED
            newRepetitions >= 2 -> LearningState.REVIEW
            else -> LearningState.LEARNING
        }

        return current.copy(
            successfulRecalls = current.successfulRecalls + 1,
            lastReviewedAt = now,
            nextReviewAt = nextReview,
            easeFactor = newEase,
            intervalDays = newIntervalDays,
            repetitions = newRepetitions,
            learningState = newState,
            recentQuality = quality
        )
    }

    /**
     * Returns true if the item is due for review at or before [now].
     */
    fun isDue(state: ExpressionReviewState, now: Instant = Instant.now()): Boolean {
        val next = state.nextReviewAt ?: return state.learningState == LearningState.NEW
        return !next.isAfter(now)
    }

    /**
     * Calculate XP for a review based on rating and current state.
     * Idempotent: caller must ensure attempt is recorded only once.
     */
    fun calculateReviewXp(rating: ReviewRating, state: ExpressionReviewState): Int {
        val base = when (rating) {
            ReviewRating.AGAIN -> 0
            ReviewRating.HARD -> 5
            ReviewRating.GOOD -> 10
            ReviewRating.EASY -> 15
        }
        val stateBonus = when (state.learningState) {
            LearningState.RELEARNING -> 2
            LearningState.LEARNING -> 3
            LearningState.REVIEW -> 5
            LearningState.MASTERED -> 1
            LearningState.NEW -> 4
        }
        return base + stateBonus
    }

    /**
     * Level formula: level = floor(sqrt(totalXp / 50)) + 1
     * Transparent and progressive.
     */
    fun calculateLevel(totalXp: Int): Int {
        if (totalXp <= 0) return 1
        return (kotlin.math.sqrt(totalXp / 50.0).toInt()) + 1
    }

    /**
     * XP required to reach a given level.
     */
    fun xpForLevel(level: Int): Int {
        if (level <= 1) return 0
        val prev = level - 1
        return (prev * prev * 50)
    }
}
