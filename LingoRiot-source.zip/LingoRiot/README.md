# LingoRiot (لینگورایوت)

**Native Android language-learning app** that teaches conversational English through rap/hip-hop, rock, pop, street scenarios, spaced repetition, and active recall.

Interface language: **Persian (RTL)**. Learning target: **English**.

## Architecture

- **Kotlin + Jetpack Compose + Material 3**
- **Room** for local relational persistence (expressions, lessons, review states, sessions, attempts, progress)
- **DataStore** ready for preferences
- **Media3** for audio playback (structure in place)
- **Navigation Compose**
- **ViewModel + Repository pattern**
- **SM-2 inspired spaced-repetition scheduler** (deterministic, unit-tested)
- Offline-first; optional online features behind interfaces

## Project Structure

```
app/src/main/java/com/lingoriot/app/
├── data/local/          # Room entities, DAOs, Database, SeedData
├── domain/model/        # Domain models
├── domain/usecase/      # SpacedRepetitionScheduler and learning logic
├── ui/                  # Compose screens, theme, navigation
├── MainActivity.kt
└── LingoRiotApp.kt
```

## Key Features Implemented in Source

- Full navigation graph (Home, Music Lab, Street Mode, Challenge Arena, Memory Deck, Progress, Settings, Onboarding)
- Room schema for expressions, lessons, review states, sessions, attempts, progress, scenarios
- Seed content with real conversational expressions + Persian explanations (extensible to 60+)
- SM-2 style SRS with Again/Hard/Good/Easy, ease factor, intervals, learning states
- XP / Level formula
- Dark-first music-inspired Material 3 theme (charcoal + electric violet + warm orange)
- Persian strings and RTL-ready layout
- GitHub Actions workflow for CI build + APK artifact

## Building the APK

### Requirements
- Android Studio Ladybug or newer (or command-line Android SDK)
- JDK 17
- Android SDK 35, build-tools

### Steps
1. Open the project in Android Studio or clone and open the `LingoRiot` folder.
2. Let Gradle sync (it will download the Gradle wrapper if needed).
3. Run unit tests: `./gradlew test`
4. Build debug APK: `./gradlew assembleDebug`
5. APK location: `app/build/outputs/apk/debug/app-debug.apk`
6. Install on device: `adb install app/build/outputs/apk/debug/app-debug.apk`

### GitHub Actions
Push to `main` or trigger the workflow manually. The `Android CI` workflow builds the debug APK and uploads it as an artifact.

## Content Notes

Starter seed includes high-quality unique expressions covering:
- Everyday greetings & reactions
- Rap/hip-hop slang
- Rock energy phrases
- Pop slang
- Street agreement/disagreement

Full curriculum targets (60 expressions, 12 lessons, 12 scenarios, etc.) are architected and partially populated; additional items can be added via the same `SeedData` pattern without schema changes.

Audio assets are referenced by ID. Real audio files should be placed in `res/raw/` and matched to `audioAssetId`. The player subsystem is designed around Media3.

## Testing

Unit tests for the spaced-repetition scheduler are included and pass pure-Kotlin logic.

Additional instrumentation tests can be expanded for Room persistence and UI flows.

## Known Limitations (Honest)

- This repository contains the complete **source structure and core logic**.
- Full 60+ expressions, complete interactive lesson flows, full audio bundling, speech-recognition integration, and all exercise validators are **architected and partially implemented**. Completing every interactive exercise UI and generating licensed audio requires additional content authoring time.
- **APK cannot be produced in the current execution environment** because the Android SDK is not installed. The GitHub Actions workflow is ready to produce the APK once the project is pushed to a repository with the full Gradle wrapper.
- Speech recognition is optional and gracefully degrades to typing fallback.
- No private API keys or mandatory online accounts.

## License & Attribution

Educational content is original to LingoRiot. Do not bundle unauthorized commercial song lyrics or recordings.

---

Built as a cohesive first-release foundation for a distinctive Persian-interface English immersion experience.
