# LingoRiot ProGuard rules
-keep class com.lingoriot.app.data.local.entity.** { *; }
-keep class com.lingoriot.app.domain.model.** { *; }
-dontwarn kotlinx.serialization.**
