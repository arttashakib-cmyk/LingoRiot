package com.lingoriot.app.ui.screens.challenge

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun ChallengeArenaScreen() {
    val challenges = listOf(
        "تشخیص سریع معنا" to "معنی عبارت را در زمان محدود تشخیص دهید",
        "گوش بده و شناسایی کن" to "از روی صدا عبارت را پیدا کنید",
        "عبارت گمشده" to "جای خالی را پر کنید",
        "سرعت ترتیب کلمات" to "کلمات را به ترتیب درست بچینید",
        "رمزگشای اسلنگ" to "معنی اسلنگ را پیدا کنید",
        "طبیعی یا غیرطبیعی؟" to "تشخیص دهید جمله طبیعی است یا نه",
        "تطبیق زمینه" to "عبارت مناسب زمینه را انتخاب کنید",
        "پاسخ مکالمه" to "بهترین پاسخ را پیدا کنید",
        "حافظه صوتی" to "عبارتی که شنیدید را به یاد بیاورید",
        "یادآوری تأخیری" to "بعد از فاصله زمانی به یاد بیاورید"
    )

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "آرنا چالش",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "چالش‌های زمان‌دار و بدون زمان برای تقویت مهارت‌ها",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(challenges) { (title, desc) ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(text = desc, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
