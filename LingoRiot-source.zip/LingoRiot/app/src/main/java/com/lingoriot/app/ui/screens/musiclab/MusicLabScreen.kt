package com.lingoriot.app.ui.screens.musiclab

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun MusicLabScreen() {
    val pathways = listOf(
        "رپ و هیپ‌هاپ" to "عبارات و اسلنگ‌های فرهنگ رپ",
        "راک" to "انرژی و اصطلاحات فرهنگ راک",
        "پاپ" to "زبان روزمره و اسلنگ‌های پاپ",
        "عبارات روزمره" to "مکالمات طبیعی الهام‌گرفته از موسیقی"
    )

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "آزمایشگاه موسیقی",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "یادگیری انگلیسی از طریق موسیقی و فرهنگ",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(pathways) { (title, desc) ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text(text = desc, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
