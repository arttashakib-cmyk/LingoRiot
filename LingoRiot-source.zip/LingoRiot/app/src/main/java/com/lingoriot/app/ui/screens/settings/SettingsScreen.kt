package com.lingoriot.app.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lingoriot.app.R

@Composable
fun SettingsScreen() {
    var darkTheme by remember { mutableStateOf(true) }
    var soundEffects by remember { mutableStateOf(true) }
    var haptics by remember { mutableStateOf(true) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }
    var dailyTarget by remember { mutableIntStateOf(15) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = stringResource(R.string.settings),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(24.dp))

        Text("ظاهر", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("تم تاریک")
            Switch(checked = darkTheme, onCheckedChange = { darkTheme = it })
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("صدا و بازخورد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("افکت‌های صوتی")
            Switch(checked = soundEffects, onCheckedChange = { soundEffects = it })
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("بازخورد لمسی")
            Switch(checked = haptics, onCheckedChange = { haptics = it })
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("پخش صوتی: ${"%.1f".format(playbackSpeed)}x", style = MaterialTheme.typography.bodyLarge)
        Slider(value = playbackSpeed, onValueChange = { playbackSpeed = it }, valueRange = 0.5f..2.0f, steps = 5)

        Spacer(modifier = Modifier.height(16.dp))
        Text("هدف روزانه: $dailyTarget دقیقه", style = MaterialTheme.typography.bodyLarge)
        Slider(value = dailyTarget.toFloat(), onValueChange = { dailyTarget = it.toInt() }, valueRange = 5f..60f, steps = 10)

        Spacer(modifier = Modifier.height(24.dp))
        Text(stringResource(R.string.privacy_info), style = MaterialTheme.typography.bodySmall)
        Spacer(modifier = Modifier.height(8.dp))
        Text(stringResource(R.string.attribution), style = MaterialTheme.typography.bodySmall)

        Spacer(modifier = Modifier.height(24.dp))
        OutlinedButton(onClick = { /* reset confirm */ }, modifier = Modifier.fillMaxWidth()) {
            Text("بازنشانی پیشرفت")
        }
    }
}
