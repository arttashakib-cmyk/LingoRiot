package com.lingoriot.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(tableName = "expressions")
data class ExpressionEntity(
    @PrimaryKey val id: String,
    val englishText: String,
    val persianMeaning: String,
    val contextualExplanation: String,
    val register: String,
    val topic: String,
    val difficulty: String,
    val exampleSentencesJson: String, // JSON array
    val alternativesJson: String,
    val usageWarnings: String?,
    val pronunciationGuide: String?,
    val audioAssetId: String?,
    val sourceAttribution: String?,
    val tagsJson: String,
    val pathway: String
)

@Entity(tableName = "lessons")
data class LessonEntity(
    @PrimaryKey val id: String,
    val titleFa: String,
    val titleEn: String,
    val pathway: String,
    val difficulty: String,
    val descriptionFa: String,
    val expressionIdsJson: String,
    val orderIndex: Int,
    val estimatedMinutes: Int
)

@Entity(tableName = "audio_assets")
data class AudioAssetEntity(
    @PrimaryKey val id: String,
    val resourceName: String,
    val durationMs: Long,
    val attribution: String?
)

@Entity(tableName = "exercises")
data class ExerciseEntity(
    @PrimaryKey val id: String,
    val type: String,
    val expressionId: String?,
    val lessonId: String?,
    val promptFa: String,
    val promptEn: String?,
    val optionsJson: String?,
    val correctAnswer: String,
    val explanationFa: String,
    val audioAssetId: String?,
    val timeLimitSeconds: Int?
)

@Entity(
    tableName = "expression_review_states",
    indices = [Index(value = ["nextReviewAt"]), Index(value = ["learningState"])]
)
data class ExpressionReviewStateEntity(
    @PrimaryKey val expressionId: String,
    val successfulRecalls: Int = 0,
    val failedRecalls: Int = 0,
    val lastReviewedAt: Long? = null, // epoch millis
    val nextReviewAt: Long? = null,
    val easeFactor: Double = 2.5,
    val intervalDays: Double = 0.0,
    val repetitions: Int = 0,
    val learningState: String = "NEW",
    val recentQuality: Int = 0,
    val contextTagsJson: String = "[]"
)

@Entity(tableName = "learning_sessions")
data class LearningSessionEntity(
    @PrimaryKey val id: String,
    val startedAt: Long,
    val endedAt: Long?,
    val pathway: String?,
    val exercisesCompleted: Int,
    val correctCount: Int,
    val xpEarned: Int,
    val durationSeconds: Long
)

@Entity(tableName = "exercise_attempts")
data class ExerciseAttemptEntity(
    @PrimaryKey val id: String,
    val exerciseId: String,
    val expressionId: String?,
    val sessionId: String,
    val isCorrect: Boolean,
    val userAnswer: String,
    val responseTimeMs: Long,
    val rating: String?,
    val timestamp: Long,
    val xpAwarded: Int
)

@Entity(tableName = "user_progress")
data class UserProgressEntity(
    @PrimaryKey val id: Int = 1, // singleton
    val totalExpressionsEncountered: Int = 0,
    val totalSuccessfulRecalls: Int = 0,
    val totalXp: Int = 0,
    val currentLevel: Int = 1,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val lastActiveDate: String? = null,
    val listeningAccuracy: Float = 0f,
    val recallAccuracy: Float = 0f,
    val productionAccuracy: Float = 0f,
    val totalSessionSeconds: Long = 0
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val id: String,
    val titleFa: String,
    val descriptionFa: String,
    val unlockedAt: Long?,
    val isUnlocked: Boolean
)

@Entity(tableName = "scenarios")
data class ScenarioEntity(
    @PrimaryKey val id: String,
    val titleFa: String,
    val titleEn: String,
    val descriptionFa: String,
    val difficulty: String,
    val stepsJson: String
)
