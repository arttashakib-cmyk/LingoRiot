package com.lingoriot.app.ui.screens.progress

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun ProgressScreen() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "پیشرفت",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(16.dp))

        listOf(
            "عبارات دیده‌شده" to "۰",
            "یادآوری موفق" to "۰",
            "دقت شنیداری" to "—",
            "دقت یادآوری" to "—",
            "دقت تولید" to "—",
            "XP کل" to "۰",
            "سطح فعلی" to "۱",
            "رشته روزانه" to "۰",
            "زمان کل جلسات" to "۰ دقیقه"
        ).forEach { (label, value) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = label, style = MaterialTheme.typography.bodyLarge)
                Text(text = value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            HorizontalDivider()
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "آمار از داده‌های واقعی یادگیری شما محاسبه می‌شود. هنوز فعالیتی ثبت نشده است.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
