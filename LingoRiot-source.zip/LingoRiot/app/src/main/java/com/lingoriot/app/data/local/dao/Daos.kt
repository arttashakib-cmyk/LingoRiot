package com.lingoriot.app.data.local.dao

import androidx.room.*
import com.lingoriot.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpressionDao {
    @Query("SELECT * FROM expressions")
    fun getAll(): Flow<List<ExpressionEntity>>

    @Query("SELECT * FROM expressions WHERE id = :id")
    suspend fun getById(id: String): ExpressionEntity?

    @Query("SELECT * FROM expressions WHERE pathway = :pathway")
    fun getByPathway(pathway: String): Flow<List<ExpressionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ExpressionEntity>)

    @Query("SELECT COUNT(*) FROM expressions")
    suspend fun count(): Int
}

@Dao
interface LessonDao {
    @Query("SELECT * FROM lessons ORDER BY orderIndex")
    fun getAll(): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons WHERE id = :id")
    suspend fun getById(id: String): LessonEntity?

    @Query("SELECT * FROM lessons WHERE pathway = :pathway ORDER BY orderIndex")
    fun getByPathway(pathway: String): Flow<List<LessonEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<LessonEntity>)
}

@Dao
interface ReviewStateDao {
    @Query("SELECT * FROM expression_review_states")
    fun getAll(): Flow<List<ExpressionReviewStateEntity>>

    @Query("SELECT * FROM expression_review_states WHERE expressionId = :id")
    suspend fun getById(id: String): ExpressionReviewStateEntity?

    @Query("SELECT * FROM expression_review_states WHERE nextReviewAt IS NULL OR nextReviewAt <= :now ORDER BY nextReviewAt ASC")
    fun getDue(now: Long): Flow<List<ExpressionReviewStateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(state: ExpressionReviewStateEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(states: List<ExpressionReviewStateEntity>)

    @Query("SELECT COUNT(*) FROM expression_review_states WHERE nextReviewAt IS NULL OR nextReviewAt <= :now")
    suspend fun countDue(now: Long): Int
}

@Dao
interface ProgressDao {
    @Query("SELECT * FROM user_progress WHERE id = 1")
    fun getProgress(): Flow<UserProgressEntity?>

    @Query("SELECT * FROM user_progress WHERE id = 1")
    suspend fun getProgressOnce(): UserProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(progress: UserProgressEntity)

    @Query("UPDATE user_progress SET totalXp = totalXp + :xp, currentLevel = :level WHERE id = 1")
    suspend fun addXp(xp: Int, level: Int)
}

@Dao
interface SessionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: LearningSessionEntity)

    @Query("SELECT * FROM learning_sessions ORDER BY startedAt DESC LIMIT :limit")
    fun getRecent(limit: Int): Flow<List<LearningSessionEntity>>
}

@Dao
interface AttemptDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(attempt: ExerciseAttemptEntity): Long

    @Query("SELECT * FROM exercise_attempts WHERE sessionId = :sessionId")
    suspend fun getBySession(sessionId: String): List<ExerciseAttemptEntity>

    @Query("SELECT COUNT(*) FROM exercise_attempts WHERE exerciseId = :exerciseId AND isCorrect = 1")
    suspend fun countCorrectForExercise(exerciseId: String): Int
}

@Dao
interface ScenarioDao {
    @Query("SELECT * FROM scenarios")
    fun getAll(): Flow<List<ScenarioEntity>>

    @Query("SELECT * FROM scenarios WHERE id = :id")
    suspend fun getById(id: String): ScenarioEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ScenarioEntity>)
}

@Dao
interface ExerciseDao {
    @Query("SELECT * FROM exercises WHERE lessonId = :lessonId")
    suspend fun getByLesson(lessonId: String): List<ExerciseEntity>

    @Query("SELECT * FROM exercises WHERE expressionId = :expressionId")
    suspend fun getByExpression(expressionId: String): List<ExerciseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ExerciseEntity>)
}

@Dao
interface AudioAssetDao {
    @Query("SELECT * FROM audio_assets WHERE id = :id")
    suspend fun getById(id: String): AudioAssetEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<AudioAssetEntity>)
}
