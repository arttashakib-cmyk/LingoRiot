package com.lingoriot.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.lingoriot.app.R
import com.lingoriot.app.ui.screens.home.HomeScreen
import com.lingoriot.app.ui.screens.musiclab.MusicLabScreen
import com.lingoriot.app.ui.screens.street.StreetModeScreen
import com.lingoriot.app.ui.screens.challenge.ChallengeArenaScreen
import com.lingoriot.app.ui.screens.memory.MemoryDeckScreen
import com.lingoriot.app.ui.screens.progress.ProgressScreen
import com.lingoriot.app.ui.screens.settings.SettingsScreen
import com.lingoriot.app.ui.screens.onboarding.OnboardingScreen

sealed class Screen(val route: String, val titleRes: Int, val icon: ImageVector) {
    data object Home : Screen("home", R.string.home, Icons.Default.Home)
    data object MusicLab : Screen("music_lab", R.string.music_lab, Icons.Default.MusicNote)
    data object Street : Screen("street", R.string.street_mode, Icons.Default.Streetview)
    data object Challenge : Screen("challenge", R.string.challenge_arena, Icons.Default.SportsEsports)
    data object Memory : Screen("memory", R.string.memory_deck, Icons.Default.Style)
    data object Progress : Screen("progress", R.string.progress, Icons.Default.BarChart)
    data object Settings : Screen("settings", R.string.settings, Icons.Default.Settings)
    data object Onboarding : Screen("onboarding", R.string.onboarding_title, Icons.Default.Person)
}

val bottomNavItems = listOf(
    Screen.Home,
    Screen.MusicLab,
    Screen.Street,
    Screen.Challenge,
    Screen.Memory
)

@Composable
fun LingoRiotNavGraph(
    startDestination: String = Screen.Home.route
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val showBottomBar = bottomNavItems.any { it.route == currentDestination?.route }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomNavItems.forEach { screen ->
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = null) },
                            label = {
                                Text(
                                    text = stringResource(screen.titleRes),
                                    textAlign = TextAlign.Center,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            },
                            selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onNavigateToMusic = { navController.navigate(Screen.MusicLab.route) },
                    onNavigateToStreet = { navController.navigate(Screen.Street.route) },
                    onNavigateToChallenge = { navController.navigate(Screen.Challenge.route) },
                    onNavigateToMemory = { navController.navigate(Screen.Memory.route) },
                    onNavigateToProgress = { navController.navigate(Screen.Progress.route) },
                    onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                )
            }
            composable(Screen.MusicLab.route) { MusicLabScreen() }
            composable(Screen.Street.route) { StreetModeScreen() }
            composable(Screen.Challenge.route) { ChallengeArenaScreen() }
            composable(Screen.Memory.route) { MemoryDeckScreen() }
            composable(Screen.Progress.route) { ProgressScreen() }
            composable(Screen.Settings.route) { SettingsScreen() }
            composable(Screen.Onboarding.route) {
                OnboardingScreen(onComplete = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                    }
                })
            }
        }
    }
}
