package com.lingoriot.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.lingoriot.app.ui.navigation.LingoRiotNavGraph
import com.lingoriot.app.ui.theme.LingoRiotTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LingoRiotTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    LingoRiotNavGraph()
                }
            }
        }
    }
}
