package com.lingoriot.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.lingoriot.app.data.local.dao.*
import com.lingoriot.app.data.local.entity.*
import com.lingoriot.app.data.local.seed.SeedData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ExpressionEntity::class,
        LessonEntity::class,
        AudioAssetEntity::class,
        ExerciseEntity::class,
        ExpressionReviewStateEntity::class,
        LearningSessionEntity::class,
        ExerciseAttemptEntity::class,
        UserProgressEntity::class,
        AchievementEntity::class,
        ScenarioEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class LingoRiotDatabase : RoomDatabase() {
    abstract fun expressionDao(): ExpressionDao
    abstract fun lessonDao(): LessonDao
    abstract fun reviewStateDao(): ReviewStateDao
    abstract fun progressDao(): ProgressDao
    abstract fun sessionDao(): SessionDao
    abstract fun attemptDao(): AttemptDao
    abstract fun scenarioDao(): ScenarioDao
    abstract fun exerciseDao(): ExerciseDao
    abstract fun audioAssetDao(): AudioAssetDao

    companion object {
        @Volatile
        private var INSTANCE: LingoRiotDatabase? = null

        fun getInstance(context: Context): LingoRiotDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LingoRiotDatabase::class.java,
                    "lingoriot.db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Seed will be triggered from Application after DB is ready
                        }
                    })
                    .fallbackToDestructiveMigration() // For v1; proper migrations in future
                    .build()
                INSTANCE = instance
                instance
            }
        }

        fun seedIfNeeded(db: LingoRiotDatabase) {
            CoroutineScope(Dispatchers.IO).launch {
                val count = db.expressionDao().count()
                if (count == 0) {
                    SeedData.seed(db)
                }
            }
        }
    }
}
