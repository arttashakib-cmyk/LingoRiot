package com.lingoriot.app.ui.screens.street

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun StreetModeScreen() {
    val scenarios = listOf(
        "آشنایی با فرد جدید",
        "صحبت با دوستان",
        "سفارش غذا و نوشیدنی",
        "برنامه‌ریزی",
        "قبول یا رد دعوت",
        "واکنش به خبر غافلگیرکننده",
        "ابراز ناامیدی",
        "مخالفت مؤدبانه",
        "شوخی کردن",
        "درک طعنه",
        "مکالمه غیررسمی محل کار",
        "درخواست توضیح"
    )

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "حالت خیابان",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "سناریوهای واقعی مکالمه روزمره",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(scenarios) { title ->
                OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = title,
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }
    }
}
