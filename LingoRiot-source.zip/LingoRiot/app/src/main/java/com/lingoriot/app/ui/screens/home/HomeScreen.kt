package com.lingoriot.app.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lingoriot.app.R

@Composable
fun HomeScreen(
    onNavigateToMusic: () -> Unit,
    onNavigateToStreet: () -> Unit,
    onNavigateToChallenge: () -> Unit,
    onNavigateToMemory: () -> Unit,
    onNavigateToProgress: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Greeting
        Text(
            text = stringResource(R.string.greeting_default),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "سطح فعلی: مبتدی · رشته: ۰ روز",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Continue learning card
        Card(
            onClick = onNavigateToMusic,
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.continue_learning),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "درس بعدی: سلام‌های روزمره",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick stats
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatChip(label = "XP", value = "۰", modifier = Modifier.weight(1f))
            StatChip(label = "مرور سررسید", value = "۰", modifier = Modifier.weight(1f))
            StatChip(label = "رشته", value = "۰", modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "دسترسی سریع",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(12.dp))

        QuickAccessRow(
            items = listOf(
                QuickItem("آزمایشگاه موسیقی", Icons.Default.MusicNote, onNavigateToMusic),
                QuickItem("حالت خیابان", Icons.Default.Streetview, onNavigateToStreet),
                QuickItem("آرنا چالش", Icons.Default.SportsEsports, onNavigateToChallenge),
                QuickItem("دک حافظه", Icons.Default.Style, onNavigateToMemory),
                QuickItem("پیشرفت", Icons.Default.BarChart, onNavigateToProgress),
                QuickItem("تنظیمات", Icons.Default.Settings, onNavigateToSettings)
            )
        )
    }
}

@Composable
private fun StatChip(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(text = label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

data class QuickItem(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val onClick: () -> Unit)

@Composable
private fun QuickAccessRow(items: List<QuickItem>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.chunked(2).forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                rowItems.forEach { item ->
                    OutlinedCard(
                        onClick = item.onClick,
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(item.icon, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = item.title, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                if (rowItems.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}
