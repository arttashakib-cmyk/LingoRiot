package com.lingoriot.app.ui.screens.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lingoriot.app.R

@Composable
fun OnboardingScreen(onComplete: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    var level by remember { mutableStateOf("مبتدی") }
    var goal by remember { mutableStateOf("مکالمه روزمره") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        when (step) {
            0 -> {
                Text(
                    text = stringResource(R.string.onboarding_title),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text("انگلیسی را از طریق موسیقی، خیابان و مکالمات واقعی یاد بگیرید.")
                Spacer(modifier = Modifier.height(32.dp))
                Button(onClick = { step = 1 }) { Text(stringResource(R.string.next)) }
                TextButton(onClick = onComplete) { Text(stringResource(R.string.skip)) }
            }
            1 -> {
                Text("سطح فعلی انگلیسی‌تان؟", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(16.dp))
                listOf("مبتدی", "متوسط", "پیشرفته").forEach { opt ->
                    FilterChip(
                        selected = level == opt,
                        onClick = { level = opt },
                        label = { Text(opt) },
                        modifier = Modifier.padding(4.dp)
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
                Button(onClick = { step = 2 }) { Text(stringResource(R.string.next)) }
            }
            2 -> {
                Text("هدف اصلی‌تان چیست؟", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(16.dp))
                listOf("مکالمه روزمره", "درک موسیقی", "اسلنگ و اصطلاحات", "تلفظ").forEach { opt ->
                    FilterChip(
                        selected = goal == opt,
                        onClick = { goal = opt },
                        label = { Text(opt) },
                        modifier = Modifier.padding(4.dp)
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
                Button(onClick = onComplete) { Text(stringResource(R.string.start_learning)) }
            }
        }
    }
}
